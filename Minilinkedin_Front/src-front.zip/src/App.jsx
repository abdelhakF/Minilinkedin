import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import { ProfileProvider } from "./context/ProfileContext";
import { NetworkProvider } from "./context/NetworkContext";
import { SearchProvider } from "./context/SearchContext";
import { PostProvider } from "./context/PostContext";
import { NotificationProvider } from "./context/NotificationContext";
import { CandidatureProvider } from "./context/CandidatureContext";
import { AdminProvider } from "./context/AdminContext";
import Login from "./components/AuthController/Login";
import Register from "./components/AuthController/Register";
import ForgotPassword from "./components/AuthController/ForgotPassword";
import ResetPassword from "./components/AuthController/ResetPassword";
import Dashboard from "./components/AuthController/Dashboard";
import Profile from "./components/Profile/Profile";
import ProtectedRoute from "./components/AuthController/ProtectedRoute";
import NetworkPage from "./components/Network/NetworkPage";
import SearchPage from "./components/Search/SearchPage";
import NotificationsPage from "./components/Notifications/NotificationsPage";
import MyCandidatures from "./components/Candidatures/MyCandidatures";
import PostDetail from './components/Posts/PostDetail';
import AdminRoute from "./components/Admin/AdminRoute";
import AdminDashboard from "./components/Admin/AdminDashboard";
import UsersManagement from "./components/Admin/UsersManagement";
import PostsManagement from "./components/Admin/PostsManagement";
import SignalementsManagement from "./components/Admin/SignalementsManagement";
import CatalogueManagement from "./components/Admin/CatalogueManagement";
import "./App.css";

function App() {
  return (
    <Router>
      <AuthProvider>
        <ProfileProvider>
          <NetworkProvider>
            <SearchProvider>
              <PostProvider>
                <NotificationProvider>
                  <CandidatureProvider>
                    <AdminProvider>
                    <div className="app">
                      <Routes>
                        <Route path="/login" element={<Login />} />
                        <Route path="/register" element={<Register />} />
                        <Route
                          path="/forgot-password"
                          element={<ForgotPassword />}
                        />
                        <Route
                          path="/reset-password"
                          element={<ResetPassword />}
                        />
                        <Route
                          path="/dashboard"
                          element={
                            <ProtectedRoute>
                              <Dashboard />
                            </ProtectedRoute>
                          }
                        />
                        {/* ROUTE UNIQUE POUR LE PROFIL (L'ID est optionnel grâce au '?') */}
                        <Route
                          path="/profile/:id?"
                          element={
                            <ProtectedRoute>
                              <Profile />
                            </ProtectedRoute>
                          }
                        />
                        <Route
                          path="/network"
                          element={
                            <ProtectedRoute>
                              <NetworkPage />
                            </ProtectedRoute>
                          }
                        />
                        <Route
                          path="/search"
                          element={
                            <ProtectedRoute>
                              <SearchPage />
                            </ProtectedRoute>
                          }
                        />
                        <Route
                          path="/notifications"
                          element={
                            <ProtectedRoute>
                              <NotificationsPage />
                            </ProtectedRoute>
                          }
                        />
                        <Route
                          path="/candidatures"
                          element={
                            <ProtectedRoute>
                              <MyCandidatures />
                            </ProtectedRoute>
                          }
                        />
                        <Route path="/" element={<Login />} />
                        <Route
                          path="/post/:id"
                          element={
                            <ProtectedRoute>
                              <PostDetail />
                            </ProtectedRoute>
                          }
                        />
                        <Route
                          path="/admin"
                          element={
                            <AdminRoute>
                              <AdminDashboard />
                            </AdminRoute>
                          }
                        />
                        <Route
                          path="/admin/users"
                          element={
                            <AdminRoute>
                              <UsersManagement />
                            </AdminRoute>
                          }
                        />
                        <Route
                          path="/admin/posts"
                          element={
                            <AdminRoute>
                              <PostsManagement />
                            </AdminRoute>
                          }
                        />
                        <Route
                          path="/admin/signalements"
                          element={
                            <AdminRoute>
                              <SignalementsManagement />
                            </AdminRoute>
                          }
                        />
                        <Route
                          path="/admin/catalogues"
                          element={
                            <AdminRoute>
                              <CatalogueManagement />
                            </AdminRoute>
                          }
                        />
                      </Routes>
                    </div>
                    </AdminProvider>
                  </CandidatureProvider>
                </NotificationProvider>
              </PostProvider>
            </SearchProvider>
          </NetworkProvider>
        </ProfileProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;
