import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { useNotification } from '../../hooks/useNotification';

const Navbar = () => {
  const { user, logout } = useAuth();
  const { notifications } = useNotification();
  const navigate = useNavigate();

  const unreadCount = notifications.length;

  const handleLogout = async () => {
    await logout();
    navigate('/login', { replace: true });
  };

  const styles = {
    navbar: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '12px 20px',
      background: '#0f172a',
      color: 'white',
      marginBottom: '20px',
      borderRadius: '12px',
    },
    left: {
      display: 'flex',
      alignItems: 'center',
      gap: '16px',
    },
    brand: {
      fontWeight: '700',
      fontSize: '18px',
      color: 'white',
      textDecoration: 'none',
    },
    links: {
      display: 'flex',
      gap: '12px',
    },
    link: {
      color: 'white',
      textDecoration: 'none',
      padding: '8px 12px',
      borderRadius: '8px',
      background: 'rgba(255,255,255,0.08)',
      position: 'relative',
    },
    right: {
      display: 'flex',
      alignItems: 'center',
      gap: '12px',
    },
    email: {
      fontSize: '14px',
      opacity: 0.9,
    },
    logoutBtn: {
      border: 'none',
      padding: '8px 14px',
      borderRadius: '8px',
      background: '#dc2626',
      color: 'white',
      cursor: 'pointer',
      fontWeight: '600',
    },
    badge: {
      position: 'absolute',
      top: '-6px',
      right: '-6px',
      background: '#dc2626',
      color: 'white',
      borderRadius: '50%',
      width: '18px',
      height: '18px',
      fontSize: '11px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontWeight: 'bold',
    },
  };

  return (
    <nav style={styles.navbar}>
      <div style={styles.left}>
        <Link to="/dashboard" style={styles.brand}>
          MiniLinkedIn
        </Link>

        <div style={styles.links}>
          <Link to="/dashboard" style={styles.link}>Dashboard</Link>
          <Link to="/profile" style={styles.link}>Profile</Link>
          <Link to="/network" style={styles.link}>Réseau</Link>
          <Link to="/search" style={styles.link}>Recherche</Link>
          <Link to="/candidatures" style={styles.link}>Candidatures</Link>
          <Link to="/notifications" style={styles.link}>
            Notifications
            {unreadCount > 0 && <span style={styles.badge}>{unreadCount}</span>}
          </Link>
          {user?.role === 'ADMIN' && (
            <Link to="/admin" style={{ ...styles.link, background: '#7c3aed' }}>
              🛠️ Admin
            </Link>
          )}
        </div>
      </div>

      <div style={styles.right}>
        {user?.email && <span style={styles.email}>{user.email}</span>}
        <button onClick={handleLogout} style={styles.logoutBtn}>
          Déconnexion
        </button>
      </div>
    </nav>
  );
};

export default Navbar;