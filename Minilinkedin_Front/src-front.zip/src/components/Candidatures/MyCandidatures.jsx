import React, { useEffect } from 'react';
import { useCandidature } from '../../hooks/useCandidature';
import Navbar from '../Common/Navbar';

const MyCandidatures = () => {
  const { myCandidatures, loading, error, fetchMyCandidatures } = useCandidature();

  useEffect(() => { fetchMyCandidatures(); }, []);

  if (loading) return "<Navbar /><p>Chargement...</p>";
  return (
    <div>
      <Navbar />
      <h2>Mes Candidatures</h2>
      {error && <div className="error-message">{error}</div>}
      {myCandidatures.length === 0 && <p>Aucune candidature.</p>}
      {myCandidatures.map((c, i) => (
        <pre key={i}>{JSON.stringify(c, null, 2)}</pre>
      ))}
    </div>
  );
};
export default MyCandidatures;