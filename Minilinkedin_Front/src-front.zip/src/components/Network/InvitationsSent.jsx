import React from 'react';
import { useNetwork } from '../../hooks/useNetwork';

const InvitationsSent = () => {
  const { invitationsEnvoyees, cancelInvitation } = useNetwork();

  if (invitationsEnvoyees.length === 0) {
    return (
      <div className="card">
        <h3>Invitations envoyées (0)</h3>
        <p>Aucune invitation envoyée pour le moment.</p>
      </div>
    );
  }

  return (
    <div className="card">
      <h3>Invitations envoyées ({invitationsEnvoyees.length})</h3>
      {invitationsEnvoyees.map((inv) => (
        <div key={inv.id} className="list-item">
          <span>
            À : <strong>{inv.receiver?.nom || inv.receiver?.email}</strong>
            <span className={`status ${inv.status?.toLowerCase()}`}> ({inv.status})</span>
          </span>
          {inv.status === 'PENDING' && (
            <button onClick={() => cancelInvitation(inv.id)}>Annuler</button>
          )}
        </div>
      ))}
    </div>
  );
};

export default InvitationsSent;