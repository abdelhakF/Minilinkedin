import React from 'react';
import { useNetwork } from '../../hooks/useNetwork';

const InvitationsReceived = () => {
  const { invitationsRecues, acceptInvitation, rejectInvitation } = useNetwork();

  if (invitationsRecues.length === 0) {
    return (
      <div className="card">
        <h3>Invitations reçues (0)</h3>
        <p>Aucune invitation en attente.</p>
      </div>
    );
  }

  return (
    <div className="card">
      <h3>Invitations reçues ({invitationsRecues.length})</h3>
      {invitationsRecues.map((inv) => (
        <div key={inv.id} className="list-item">
          <span>
            <strong>{inv.sender?.nom || inv.sender?.email}</strong>
            {inv.sender?.headline && <small> — {inv.sender.headline}</small>}
          </span>
          <div className="actions">
            <button onClick={() => acceptInvitation(inv.id)}>✅ Accepter</button>
            <button onClick={() => rejectInvitation(inv.id)}>❌ Refuser</button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default InvitationsReceived;