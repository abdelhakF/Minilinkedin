import React from 'react';
import { useNetwork } from '../../hooks/useNetwork';

const ConnectionsList = () => {
  const { connexions } = useNetwork();

  if (connexions.length === 0) {
    return (
      <div className="card">
        <h3>Mes connexions (0)</h3>
        <p>Vous n'avez pas encore de connexions.</p>
      </div>
    );
  }

  return (
    <div className="card">
      <h3>Mes connexions ({connexions.length})</h3>
      {connexions.map((user) => (
        <div key={user.id} className="list-item">
          <span>
            <strong>{user.nom}</strong> ({user.email})
            {user.roleEnum && <small> — {user.roleEnum}</small>}
          </span>
        </div>
      ))}
    </div>
  );
};

export default ConnectionsList;