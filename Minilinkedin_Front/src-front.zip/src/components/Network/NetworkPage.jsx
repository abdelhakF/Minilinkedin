import React from 'react';
import { useNetwork } from '../../hooks/useNetwork';
import Navbar from '../Common/Navbar';
import InviteForm from './InviteForm';
import InvitationsReceived from './InvitationsReceived';
import InvitationsSent from './InvitationsSent';
import ConnectionsList from './ConnectionsList';

const NetworkPage = () => {
  const { loading, error } = useNetwork();

  if (loading) {
    return (
      <div className="page-loader">
        <Navbar />
        <p>Chargement du réseau...</p>
      </div>
    );
  }

  return (
    <div className="network-page">
      <Navbar />
      <h2>Mon Réseau</h2>

      {error && <div className="error-message">{error}</div>}

      <InviteForm />
      <InvitationsReceived />
      <InvitationsSent />
      <ConnectionsList />
    </div>
  );
};

export default NetworkPage;