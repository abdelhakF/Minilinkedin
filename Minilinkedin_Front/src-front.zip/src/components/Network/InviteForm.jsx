import React, { useState } from 'react';
import { useNetwork } from '../../hooks/useNetwork';

const InviteForm = () => {
  const { sendInvitation, error, setError } = useNetwork();
  const [email, setEmail] = useState('');
  const [sending, setSending] = useState(false);
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email.trim()) return;
    setSending(true);
    setSuccess('');
    setError(null);
    try {
      await sendInvitation(email);
      setEmail('');
      setSuccess('Invitation envoyée avec succès !');
    } catch (err) {
      // L'erreur est déjà gérée par le contexte
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="card">
      <h3>Envoyer une invitation</h3>
      <form onSubmit={handleSubmit}>
        <input
          type="email"
          placeholder="Email du destinataire"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          disabled={sending}
        />
        <button type="submit" disabled={sending}>
          {sending ? 'Envoi...' : 'Inviter'}
        </button>
      </form>
      {success && <div className="success-message">{success}</div>}
    </div>
  );
};

export default InviteForm;