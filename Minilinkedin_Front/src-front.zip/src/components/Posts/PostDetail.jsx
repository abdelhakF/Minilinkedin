import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { MessageSquare, ThumbsUp, Calendar, Tag, ArrowLeft } from 'lucide-react';
import Navbar from '../Common/Navbar';
import postService from '../../services/postService';
import '../Profile/ProfilePostList.css'; // On réutilise le CSS existant

const PostDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  
  const [post, setPost] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchPost = async () => {
      try {
        setLoading(true);
        // On récupère les données du post via l'API
        const data = await postService.getPostById(id); 
        setPost(data);
      } catch (err) {
        setError("Cette publication n'existe pas ou a été supprimée.");
      } finally {
        setLoading(false);
      }
    };

    fetchPost();
  }, [id]);

  if (loading) return (
    <>
      <Navbar />
      <div style={{ marginTop: '100px', textAlign: 'center' }}>Chargement de la publication...</div>
    </>
  );

  if (error) return (
    <>
      <Navbar />
      <div style={{ marginTop: '100px', textAlign: 'center', color: '#d32f2f' }}>{error}</div>
    </>
  );

  // Extraction des infos auteur (nom et initiale)
  const authorName = post.author?.nom || post.createur?.nom || post.utilisateur?.nom || 'Utilisateur';
  const initial = authorName.charAt(0).toUpperCase();

  return (
    <div className="li-page-container">
      <Navbar />
      
      <main className="li-main-layout" style={{ marginTop: '80px', display: 'flex', justifyContent: 'center' }}>
        <div style={{ width: '100%', maxWidth: '700px' }}>
          
          {/* Bouton Retour */}
          <button 
            onClick={() => navigate(-1)} 
            style={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: '8px', 
              background: 'none', 
              border: 'none', 
              color: '#0a66c2', 
              fontWeight: '600', 
              cursor: 'pointer',
              marginBottom: '16px',
              padding: '8px 0'
            }}
          >
            <ArrowLeft size={20} />
            Retour
          </button>

          {/* Carte du Post complet */}
          <div className="profile-post-card" style={{ padding: '24px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
            
            {/* EN-TÊTE : Auteur et Date */}
            <div className="post-author-info" style={{ display: 'flex', alignItems: 'center', marginBottom: '20px' }}>
              <div style={{ 
                width: '56px', 
                height: '56px', 
                borderRadius: '50%', 
                backgroundColor: '#0a66c2', 
                color: 'white', 
                display: 'flex', 
                alignItems: 'center', 
                justifyContent: 'center',
                fontWeight: 'bold',
                fontSize: '22px',
                marginRight: '14px'
              }}>
                {initial}
              </div>
              
              <div className="post-author-details">
                <div style={{ fontWeight: '700', fontSize: '16px', color: 'rgba(0,0,0,0.9)' }}>
                  {authorName}
                </div>
                <div style={{ fontSize: '13px', color: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', marginTop: '4px' }}>
                  <Calendar size={14} style={{ marginRight: 6 }} />
                  Publié le {new Date(post.createdAt).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}
                </div>
              </div>

              {post.type && (
                <div className="post-badge" style={{ marginLeft: 'auto', padding: '6px 12px' }}>
                  <Tag size={14} style={{ marginRight: 6 }} />
                  {post.type}
                </div>
              )}
            </div>

            {/* CORPS : Titre et Contenu */}
            <div className="post-card-body" style={{ borderBottom: '1px solid #e0e0e0', paddingBottom: '20px' }}>
              {post.titre && (
                <h2 style={{ fontSize: '22px', color: '#0a66c2', marginBottom: '16px', fontWeight: '600' }}>
                  {post.titre}
                </h2>
              )}
              <p style={{ 
                fontSize: '16px', 
                lineHeight: '1.6', 
                color: 'rgba(0,0,0,0.8)', 
                whiteSpace: 'pre-wrap' 
              }}>
                {post.content}
              </p>
            </div>

            {/* PIED : Interactions */}
            <div className="post-card-footer" style={{ marginTop: '16px', display: 'flex', gap: '24px' }}>
              <div className="metric" style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'rgba(0,0,0,0.6)', cursor: 'pointer' }}>
                <ThumbsUp size={20} />
                <span style={{ fontWeight: '600' }}>{post.likesCount || 0} J'aime</span>
              </div>
              <div className="metric" style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'rgba(0,0,0,0.6)', cursor: 'pointer' }}>
                <MessageSquare size={20} />
                <span style={{ fontWeight: '600' }}>{post.comments?.length || 0} Commentaires</span>
              </div>
            </div>

          </div>
        </div>
      </main>
    </div>
  );
};

export default PostDetail;