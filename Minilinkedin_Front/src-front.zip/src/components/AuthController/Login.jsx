import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../../hooks/useAuth';
import authService from '../../services/authService';

const redirectPathFor = (role) => (role === 'ADMIN' ? '/admin' : '/profile');

const detectAdminFromApi = async () => {
  const token = localStorage.getItem('token');
  if (!token) return false;
  try {
    await axios.get('http://localhost:8080/api/admin/stats', {
      headers: { Authorization: `Bearer ${token}` },
    });
    return true;
  } catch {
    return false;
  }
};

const resolveRedirect = async (knownRole) => {
  if (knownRole === 'ADMIN') return '/admin';
  if (knownRole) return '/profile';
  // Rôle inconnu : tentative de détection ADMIN via l'API
  const isAdmin = await detectAdminFromApi();
  if (isAdmin) {
    localStorage.setItem('userRole', 'ADMIN');
    return '/admin';
  }
  return '/profile';
};

const Login = () => {
  const { login, isAuthenticated, user } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loadingForm, setLoadingForm] = useState(false);

  useEffect(() => {
    if (isAuthenticated) {
      (async () => {
        const path = await resolveRedirect(user?.role);
        navigate(path, { replace: true });
      })();
    }
  }, [isAuthenticated, user, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoadingForm(true);
    setError('');

    try {
      await login(email, password);
      const current = authService.getCurrentUser();
      const path = await resolveRedirect(current?.role);
      navigate(path, { replace: true });
    } catch (err) {
      const message =
        err?.response?.data ||
        err?.response?.data?.message ||
        'Invalid credentials';

      setError(typeof message === 'string' ? message : 'Invalid credentials');
      console.log('LOGIN ERROR:', err?.response?.status, err?.response?.data);
    } finally {
      setLoadingForm(false);
    }
  };

  const styles = {
    page: {
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: '#f8fafc',
      padding: '20px',
    },
    card: {
      width: '100%',
      maxWidth: '420px',
      background: 'white',
      borderRadius: '16px',
      padding: '28px',
      boxShadow: '0 10px 30px rgba(0,0,0,0.08)',
    },
    title: {
      marginBottom: '20px',
      textAlign: 'center',
    },
    formGroup: {
      display: 'flex',
      flexDirection: 'column',
      gap: '8px',
      marginBottom: '16px',
    },
    input: {
      padding: '12px',
      borderRadius: '10px',
      border: '1px solid #cbd5e1',
      outline: 'none',
    },
    button: {
      width: '100%',
      padding: '12px',
      border: 'none',
      borderRadius: '10px',
      background: '#2563eb',
      color: 'white',
      fontWeight: '600',
      cursor: 'pointer',
      marginTop: '8px',
    },
    error: {
      background: '#fee2e2',
      color: '#991b1b',
      padding: '10px',
      borderRadius: '10px',
      marginBottom: '16px',
    },
    links: {
      marginTop: '16px',
      display: 'flex',
      justifyContent: 'space-between',
      fontSize: '14px',
    },
  };

  return (
    <div style={styles.page}>
      <form style={styles.card} onSubmit={handleSubmit}>
        <h2 style={styles.title}>Login</h2>

        {error && <div style={styles.error}>{error}</div>}

        <div style={styles.formGroup}>
          <label>Email</label>
          <input
            style={styles.input}
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            autoComplete="email"
          />
        </div>

        <div style={styles.formGroup}>
          <label>Password</label>
          <input
            style={styles.input}
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            autoComplete="current-password"
          />
        </div>

        <button style={styles.button} type="submit" disabled={loadingForm}>
          {loadingForm ? 'Connecting...' : 'Login'}
        </button>

        <div style={styles.links}>
          <Link to="/register">Create account</Link>
          <Link to="/forgot-password">Forgot password?</Link>
        </div>
      </form>
    </div>
  );
};

export default Login;