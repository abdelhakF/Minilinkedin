import React, { useState, useEffect } from 'react';
import { MessageSquare, ThumbsUp, Trash2, Calendar, Tag } from 'lucide-react'; // 👈 Ajout de Tag
import postService from '../../services/postService';
import './ProfilePostList.css'; 

const ProfilePostList = ({ isOwner }) => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchMyPosts = async () => {
    try {
      setLoading(true);
      const data = await postService.getMyPosts();
      const sortedPosts = data.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
      setPosts(sortedPosts);
    } catch (err) {
      setError("Impossible de charger les publications.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMyPosts();
  }, []);

  const handleDelete = async (postId) => {
    if (window.confirm("Voulez-vous vraiment supprimer cette publication ?")) {
      try {
        await postService.deleteMyPost(postId);
        setPosts(posts.filter(p => p.id !== postId));
      } catch (err) {
        alert("Erreur lors de la suppression");
      }
    }
  };

  if (loading) return <div>Chargement des publications...</div>;
  if (error) return <div className="profile-error">{error}</div>;

  return (
    <div className="section-card">
      <div className="section-header">
        <h2 className="section-title">Publications récentes</h2>
      </div>

      <div className="profile-posts-container">
        {posts.length === 0 ? (
          <p className="empty-state">Aucune publication trouvée.</p>
        ) : (
          <div className="profile-posts-grid">
            {posts.map(post => {
              // 👇 Récupération robuste du nom (selon ce que le backend envoie)
              const authorName = post.author?.nom || post.createur?.nom || post.utilisateur?.nom || 'Utilisateur';
              const initial = authorName.charAt(0).toUpperCase();

              return (
                <div key={post.id} className="profile-post-card">
                  
                  {/* ── NOUVEL EN-TÊTE : Avatar, Nom, Date, Type ── */}
                  <div className="post-author-info" style={{ display: 'flex', alignItems: 'center', marginBottom: '16px' }}>
                    
                    {/* Avatar */}
                    <div style={{ 
                      width: '48px', 
                      height: '48px', 
                      borderRadius: '50%', 
                      backgroundColor: '#0a66c2', 
                      color: 'white', 
                      display: 'flex', 
                      alignItems: 'center', 
                      justifyContent: 'center',
                      fontWeight: 'bold',
                      fontSize: '18px',
                      marginRight: '12px'
                    }}>
                      {initial}
                    </div>
                    
                    {/* Infos (Nom + Date) */}
                    <div className="post-author-details" style={{ display: 'flex', flexDirection: 'column' }}>
                      <span style={{ fontWeight: '600', fontSize: '15px', color: 'rgba(0,0,0,0.9)' }}>
                        {authorName}
                      </span>
                      <span style={{ fontSize: '12px', color: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', marginTop: '2px' }}>
                        <Calendar size={12} style={{ marginRight: 4 }} />
                        {new Date(post.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    
                    {/* Badge du Type de publication */}
                    {post.type && (
                      <div className="post-badge" style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', fontSize: '12px', padding: '4px 8px', backgroundColor: '#eef3f8', color: '#0a66c2', borderRadius: '4px', fontWeight: '600' }}>
                        <Tag size={12} style={{ marginRight: 4 }} />
                        {post.type}
                      </div>
                    )}
                  </div>

                  {/* ── CORPS DE LA PUBLICATION ── */}
                  <div className="post-card-body">
                    {post.titre && <h4 className="post-sub-title" style={{ marginBottom: '8px', fontSize: '16px', color: '#0a66c2' }}>{post.titre}</h4>}
                    <p className="post-text-preview" style={{ fontSize: '14px', lineHeight: '1.5', color: 'rgba(0,0,0,0.9)', whiteSpace: 'pre-wrap' }}>
                      {post.content}
                    </p>
                  </div>

                  {/* ── PIED DE LA PUBLICATION (Boutons) ── */}
                  <div className="post-card-footer" style={{ marginTop: '16px', paddingTop: '12px', borderTop: '1px solid #e0e0e0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    
                    <div className="post-metrics" style={{ display: 'flex', gap: '16px' }}>
                      <div className="metric" style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'rgba(0,0,0,0.6)', fontSize: '14px' }}>
                        <ThumbsUp size={16} />
                        <span>{post.likesCount || 0}</span>
                      </div>
                      <div className="metric" style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'rgba(0,0,0,0.6)', fontSize: '14px' }}>
                        <MessageSquare size={16} />
                        <span>{post.comments?.length || 0}</span>
                      </div>
                    </div>
                    
                    {/* Le bouton supprimer apparaît uniquement pour le propriétaire */}
                    {isOwner && (
                      <button 
                        onClick={() => handleDelete(post.id)} 
                        className="btn-delete-post"
                        title="Supprimer la publication"
                        style={{ background: 'none', border: 'none', color: '#d32f2f', cursor: 'pointer', padding: '4px', display: 'flex', alignItems: 'center' }}
                      >
                        <Trash2 size={18} />
                      </button>
                    )}
                  </div>

                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default ProfilePostList;