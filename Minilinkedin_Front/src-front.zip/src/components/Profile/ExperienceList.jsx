import React, { useState, useEffect } from 'react';
import { Plus, PencilLine, Trash2, X, Briefcase, Calendar } from 'lucide-react';
import profileService from '../../services/profileService';
import { useProfile } from '../../hooks/useProfile';

const emptyForm = {
  title: '',
  company: '',
  location: '',
  from: '',
  to: '',
  description: '',
};

const formatDate = (str) => {
  if (!str) return '';
  const d = new Date(str);
  return d.toLocaleDateString('en-GB', { month: 'short', year: 'numeric' });
};

const ExperienceList = ({ profileId, isOwner }) => {
  const { addExperience, updateExperience, removeExperience } = useProfile();
  const [experiences, setExperiences] = useState([]);
  const [editing, setEditing] = useState(null);
  const [formData, setFormData] = useState(emptyForm);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    if (profileId) {
      profileService
        .getExperiences(profileId)
        .then(setExperiences)
        .catch((err) => setError(err.response?.data || 'Failed to load experiences'));
    }
  }, [profileId]);

  const resetForm = () => {
    setEditing(null);
    setFormData(emptyForm);
    setError('');
    setShowForm(false);
  };

  const validate = () => {
    if (!formData.title || !formData.company || !formData.from) {
      setError('Title, Company and Start Date are required.');
      return false;
    }
    return true;
  };

  const handleAdd = async () => {
    if (!validate()) return;
    setError('');
    setLoading(true);
    try {
      await addExperience({ ...formData, to: formData.to || null });
      const data = await profileService.getExperiences(profileId);
      setExperiences(data);
      resetForm();
    } catch (err) {
      setError(err.response?.data || err.message || 'Failed to add experience');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async () => {
    if (!editing || !validate()) return;
    setError('');
    setLoading(true);
    try {
      await updateExperience(editing.id, { ...formData, to: formData.to || null });
      const data = await profileService.getExperiences(profileId);
      setExperiences(data);
      resetForm();
    } catch (err) {
      setError(err.response?.data || err.message || 'Failed to update experience');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this experience?')) return;
    try {
      await removeExperience(id);
      setExperiences(experiences.filter((exp) => exp.id !== id));
    } catch (err) {
      alert(err.response?.data || err.message);
    }
  };

  const handleEdit = (exp) => {
    setEditing(exp);
    setFormData({
      title: exp.title || '',
      company: exp.company || '',
      location: exp.location || '',
      from: exp.from || '',
      to: exp.to || '',
      description: exp.description || '',
    });
    setShowForm(true);
    setError('');
  };

  const onChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <div className="section-card">
      <div className="section-header">
        <h2 className="section-title">
          <Briefcase size={20} className="section-icon" /> Work Experience
        </h2>

        {isOwner && (
          <button
            type="button"
            className="btn-icon"
            aria-label={showForm && !editing ? 'Close form' : 'Add experience'}
            title={showForm && !editing ? 'Close' : 'Add experience'}
            onClick={() => {
              setShowForm((prev) => !prev);
              setEditing(null);
              setFormData(emptyForm);
              setError('');
            }}
          >
            {showForm && !editing ? (
              <X size={16} strokeWidth={2.2} />
            ) : (
              <Plus size={16} strokeWidth={2.2} />
            )}
          </button>
        )}
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      {experiences.length === 0 && !showForm && (
        <p className="empty-state">No work experience added yet.</p>
      )}

      {experiences.map((exp) => (
        <div key={exp.id} className="section-item">
          <div style={{ display: 'flex', gap: 14, minWidth: 0, flex: 1 }}>
            <div className="item-icon-col">
              <Briefcase size={18} strokeWidth={1.8} />
            </div>

            <div className="item-body">
              <p className="item-title">{exp.title}</p>
              <p className="item-sub">
                {exp.company}
                {exp.location && (
                  <span style={{ color: 'var(--c-text-3)' }}> · {exp.location}</span>
                )}
              </p>
              <p className="item-date">
                <Calendar size={12} strokeWidth={2} />
                {formatDate(exp.from)} — {exp.to ? formatDate(exp.to) : 'Present'}
              </p>
              {exp.description && <p className="item-desc">{exp.description}</p>}
            </div>
          </div>

          {isOwner && (
            <div className="item-actions">
              <button
                type="button"
                className="btn-action"
                onClick={() => handleEdit(exp)}
                aria-label="Edit experience"
                title="Edit"
              >
                <PencilLine size={13} strokeWidth={2} />
              </button>
              <button
                type="button"
                className="btn-action danger"
                onClick={() => handleDelete(exp.id)}
                aria-label="Delete experience"
                title="Delete"
              >
                <Trash2 size={13} strokeWidth={2} />
              </button>
            </div>
          )}
        </div>
      ))}

      {isOwner && showForm && (
        <div className="inline-form">
          <p className="inline-form-title">
            {editing ? 'Edit experience' : 'Add experience'}
          </p>

          <div className="form-row">
            <div className="form-field">
              <label>Job title *</label>
              <input
                name="title"
                placeholder="e.g., Stage Développeur Java"
                value={formData.title}
                onChange={onChange}
              />
            </div>
            <div className="form-field">
              <label>Company *</label>
              <input
                name="company"
                placeholder="e.g., Capgemini"
                value={formData.company}
                onChange={onChange}
              />
            </div>
          </div>

          <div className="form-field">
            <label>Location</label>
            <input
              name="location"
              placeholder="e.g., Paris La Défense"
              value={formData.location}
              onChange={onChange}
            />
          </div>

          <div className="form-row">
            <div className="form-field">
              <label>Start date *</label>
              <input type="date" name="from" value={formData.from} onChange={onChange} />
            </div>
            <div className="form-field">
              <label>
                End date{' '}
                <span style={{ fontWeight: 400, textTransform: 'none', letterSpacing: 0 }}>
                  (leave empty if current)
                </span>
              </label>
              <input type="date" name="to" value={formData.to} onChange={onChange} />
            </div>
          </div>

          <div className="form-field">
            <label>Description</label>
            <textarea
              name="description"
              placeholder="Describe your responsibilities and achievements…"
              value={formData.description}
              onChange={onChange}
            />
          </div>

          <div className="form-actions">
            <button
              type="button"
              className="btn btn-primary"
              onClick={editing ? handleUpdate : handleAdd}
              disabled={loading}
            >
              {loading ? 'Saving…' : editing ? 'Update' : 'Add'}
            </button>
            <button type="button" className="btn btn-cancel" onClick={resetForm}>
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ExperienceList;