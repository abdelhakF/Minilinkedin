import React, { useState, useEffect } from 'react';
import { Plus, PencilLine, Trash2, X } from 'lucide-react';
import profileService from '../../services/profileService';
import { useProfile } from '../../hooks/useProfile';

const SKILL_LEVELS = ['BEGINNER', 'INTERMEDIATE', 'ADVANCED', 'EXPERT'];

const LEVEL_META = {
  BEGINNER: { label: 'Beginner', short: 'Beginner', cls: 'skill-chip-beginner' },
  INTERMEDIATE: { label: 'Intermediate', short: 'Intermediate', cls: 'skill-chip-intermediate' },
  ADVANCED: { label: 'Advanced', short: 'Advanced', cls: 'skill-chip-advanced' },
  EXPERT: { label: 'Expert', short: 'Expert', cls: 'skill-chip-expert' },
};

const emptyForm = { name: '', level: 'BEGINNER' };

const SkillList = ({ profileId, isOwner }) => {
  const { addSkill, updateSkill, removeSkill } = useProfile();
  const [skills, setSkills] = useState([]);
  const [editing, setEditing] = useState(null);
  const [formData, setFormData] = useState(emptyForm);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    if (profileId) {
      profileService
        .getSkills(profileId)
        .then(setSkills)
        .catch((err) => setError(err.response?.data || 'Failed to load skills'));
    }
  }, [profileId]);

  const resetForm = () => {
    setEditing(null);
    setFormData(emptyForm);
    setError('');
    setShowForm(false);
  };

  const handleAdd = async () => {
    if (!formData.name.trim()) {
      setError('Skill name is required.');
      return;
    }
    setError('');
    setLoading(true);
    try {
      await addSkill(formData);
      const data = await profileService.getSkills(profileId);
      setSkills(data);
      resetForm();
    } catch (err) {
      setError(err.response?.data || err.message || 'Failed to add skill');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async () => {
    if (!editing) return;
    if (!formData.name.trim()) {
      setError('Skill name is required.');
      return;
    }
    setError('');
    setLoading(true);
    try {
      await updateSkill(editing.id, formData);
      const data = await profileService.getSkills(profileId);
      setSkills(data);
      resetForm();
    } catch (err) {
      setError(err.response?.data || err.message || 'Failed to update skill');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this skill?')) return;
    try {
      await removeSkill(id);
      setSkills(skills.filter((s) => s.id !== id));
    } catch (err) {
      alert(err.response?.data || err.message);
    }
  };

  const handleEdit = (skill) => {
    setEditing(skill);
    setShowForm(true);
    setFormData({
      name: skill.name || '',
      level: skill.level || 'BEGINNER',
    });
    setError('');
  };

  const onChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <div className="section-card">
      {/* Header */}
      <div className="section-header">
        <h2 className="section-title">Skills</h2>

        {isOwner && (
          <button
            type="button"
            className="btn-icon"
            aria-label={showForm && !editing ? 'Close form' : 'Add skill'}
            title={showForm && !editing ? 'Close' : 'Add skill'}
            onClick={() => {
              setShowForm((prev) => !prev);
              setEditing(null);
              setFormData(emptyForm);
              setError('');
            }}
          >
            {showForm && !editing ? (
              <X size={24} strokeWidth={2.2} />
            ) : (
              <Plus size={24} strokeWidth={2.2} />
            )}
          </button>
        )}
      </div>

      {/* Error */}
      {error && <div className="alert alert-error">{error}</div>}

      {/* Empty state */}
      {skills.length === 0 && !showForm && (
        <p className="empty-state">No skills added yet.</p>
      )}

      {/* Chip grid */}
      {skills.length > 0 && (
        <div className="skills-grid">
          {skills.map((skill) => {
            const meta = LEVEL_META[skill.level] || LEVEL_META.BEGINNER;
            return (
              <div key={skill.id} className={`skill-chip ${meta.cls}`}>
                <span className="skill-level-dot" aria-hidden="true" />
                <span style={{ fontWeight: 600 }}>{skill.name}</span>
                <span style={{ opacity: 0.7, fontSize: '0.75em' }}>
                  {meta.short}
                </span>

                {isOwner && (
                  <span className="skill-chip-actions">
                    <button
                      type="button"
                      className="skill-chip-btn"
                      onClick={() => handleEdit(skill)}
                      aria-label="Edit skill"
                      title="Edit"
                    >
                      <PencilLine size={16} strokeWidth={2.5} />
                    </button>
                    <button
                      type="button"
                      className="skill-chip-btn danger"
                      onClick={() => handleDelete(skill.id)}
                      aria-label="Delete skill"
                      title="Delete"
                    >
                      <Trash2 size={16} strokeWidth={2.5} />
                    </button>
                  </span>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Inline form */}
      {isOwner && showForm && (
        <div className="inline-form">
          <p className="inline-form-title">
            {editing ? 'Edit skill' : 'Add skill'}
          </p>

          <div className="form-row">
            <div className="form-field">
              <label>Skill name *</label>
              <input
                type="text"
                name="name"
                placeholder="e.g., Java, React, SQL…"
                value={formData.name}
                onChange={onChange}
              />
            </div>
            <div className="form-field">
              <label>Level</label>
              <select name="level" value={formData.level} onChange={onChange}>
                {SKILL_LEVELS.map((lvl) => (
                  <option key={lvl} value={lvl}>
                    {LEVEL_META[lvl].label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="form-actions">
            <button
              type="button"
              className="btn btn-primary"
              onClick={editing ? handleUpdate : handleAdd}
              disabled={loading}
            >
              {loading ? 'Saving…' : editing ? 'Update' : 'Add'}
            </button>
            <button type="button" className="btn btn-cancel" onClick={resetForm}>
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default SkillList;