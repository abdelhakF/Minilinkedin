import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useProfile } from '../../hooks/useProfile';
import ProfileForm from './ProfileForm';
import ProfileHeader from './ProfileHeader';
import ExperienceList from './ExperienceList';
import EducationList from './EducationList';
import SkillList from './SkillList';
import AccomplishmentList from './AccomplishmentList';
import Navbar from '../Common/Navbar';
import RecommendationList from './RecommendationList';
import ProfilePostList from './ProfilePostList';
import './Profile.css';

const Profile = () => {
  const { id } = useParams();
  const { profile: myProfile, getProfileById, loading: contextLoading, error, refreshProfile } = useProfile();
  
  const [showEditForm, setShowEditForm] = useState(false);
  const [displayedProfile, setDisplayedProfile] = useState(null);
  const [localLoading, setLocalLoading] = useState(true);

  // 👇 LOGIQUE CORRIGÉE : Tu es propriétaire si (pas d'id) OU (l'id de l'URL est ton id utilisateur)
  const isOwner = !id || (myProfile && String(myProfile.utilisateur?.id) === String(id)); 

  useEffect(() => {
    if (id) {
      setLocalLoading(true);
      getProfileById(id).then(data => {
        setDisplayedProfile(data);
        setLocalLoading(false);
      });
    } else {
      setDisplayedProfile(myProfile);
      setLocalLoading(contextLoading);
    }
  }, [id, myProfile, getProfileById, contextLoading]);

  const profile = displayedProfile;
  const displayName = profile?.utilisateur?.nom || 'Unknown User';

  /* ── Loading ── */
  if (localLoading) {
    return (
      <div className="profile-container">
        <Navbar />
        <div className="profile-state-card profile-loading-state">
          <div className="profile-spinner" />
          <p>Loading your professional profile…</p>
        </div>
      </div>
    );
  }

  /* ── Create profile (first-time) OR Profile Not Found ── */
  if (!profile) {
    if (isOwner) {
      return (
        <div className="profile-container">
          <Navbar />
          <div className="profile-state-card create-profile-welcome">
            <span className="profile-state-badge">Profile</span>
            <h2>Welcome! Create your profile to get started</h2>
            <p>Complete your information to become visible to recruiters.</p>
            {error && <div className="profile-error">{error}</div>}
            <ProfileForm onSuccess={() => refreshProfile()} />
          </div>
        </div>
      );
    } else {
      return (
        <div className="profile-container">
          <Navbar />
          <div className="profile-state-card create-profile-welcome">
            <span className="profile-state-badge">Erreur</span>
            <h2>Profil introuvable</h2>
            <p>L'utilisateur que vous recherchez n'a pas encore créé son profil.</p>
          </div>
        </div>
      );
    }
  }

  /* ── Sidebar stats ── */
  const stats = [
    { label: 'Experiences', value: profile.experiences?.length ?? 0 },
    { label: 'Education', value: profile.educations?.length ?? 0 },
    { label: 'Skills', value: profile.skills?.length ?? 0 },
    { label: 'Accomplishments', value: profile.accomplishments?.length ?? 0 },
  ];

  return (
    <div className="profile-container">
      <Navbar />

      <div className="profile-layout">

        {/* ── Main column ── */}
        <main className="profile-main">

          {/* Profile header card */}
          <ProfileHeader
            profile={profile}
            // On masque le bouton Modifier si on n'est pas propriétaire
            onEdit={isOwner ? () => setShowEditForm((prev) => !prev) : null}
          />
          
          <ProfilePostList />
          
          {/* Inline edit form */}
          {isOwner && showEditForm && (
            <ProfileForm
              initialData={profile}
              onSuccess={() => {
                setShowEditForm(false);
                refreshProfile();
              }}
              onCancel={() => setShowEditForm(false)}
            />
          )}

          {/* Section cards : On passe isOwner partout pour masquer les boutons d'ajout/suppression si besoin */}
          <div className="profile-sections">
            <ExperienceList profileId={profile.id} isOwner={isOwner} />
            <EducationList profileId={profile.id} isOwner={isOwner} />
            <SkillList profileId={profile.id} isOwner={isOwner} />
            <AccomplishmentList profileId={profile.id} isOwner={isOwner} />
            <RecommendationList profileId={profile.id} isOwner={isOwner} />
          </div>
        </main>

        {/* ── Sidebar ── */}
        <aside className="profile-sidebar">
          {/* Identity card */}
          <section className="sidebar-card">
            <h3>Profile overview</h3>
            <div className="sidebar-identity">
              <div className="sidebar-avatar">
                {profile.photoUrl
                  ? <img src={profile.photoUrl} alt={displayName} />
                  : <span>{displayName.charAt(0).toUpperCase()}</span>}
              </div>
              <div>
                <strong>{displayName}</strong>
                <p>{profile.headline || 'No headline set yet'}</p>
              </div>
            </div>
            {profile.summary && (
              <p className="sidebar-summary">{profile.summary}</p>
            )}
          </section>

          {/* Quick stats */}
          <section className="sidebar-card">
            <h3>Quick stats</h3>
            <div className="stats-grid">
              {stats.map((item) => (
                <div key={item.label} className="stat-pill">
                  <span className="stat-value">{item.value}</span>
                  <span className="stat-label">{item.label}</span>
                </div>
              ))}
            </div>
          </section>

          {/* Profile details */}
          <section className="sidebar-card">
            <h3>Profile details</h3>
            <div className="sidebar-details">
              <div>
                <span className="detail-label">Name</span>
                <span className="detail-value">{displayName}</span>
              </div>
              <div>
                <span className="detail-label">Headline</span>
                <span className="detail-value">{profile.headline || '—'}</span>
              </div>
              <div>
                <span className="detail-label">Summary</span>
                <span className="detail-value">
                  {profile.summary ? 'Completed ✓' : 'Not added yet'}
                </span>
              </div>
              {profile.institution && (
                <div>
                  <span className="detail-label">Institution</span>
                  <span className="detail-value">{profile.institution}</span>
                </div>
              )}
            </div>
          </section>

        </aside>
      </div>
    </div>
  );
};

export default Profile;