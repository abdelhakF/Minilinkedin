import React from 'react';
import { PencilLine, MessageSquare, MoreHorizontal, MapPin, CheckCircle2, Clock } from 'lucide-react';

const ProfileHeader = ({ profile, onEdit }) => {
  if (!profile) return null;

  const displayName = profile.utilisateur?.nom || 'Unknown User';
  const initials = displayName
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p.charAt(0).toUpperCase())
    .join('');

  const profileComplete =
    !!profile.headline &&
    !!profile.summary &&
    (profile.experiences?.length ?? 0) > 0;

  return (
    <section className="section-card" style={{ padding: 0 }}>
      {/* Cover banner */}
      <div className="profile-cover" />

      {/* Body */}
      <div className="profile-header-body">
        {/* Avatar */}
        <div className="profile-avatar-wrap">
          {profile.photoUrl ? (
            <img src={profile.photoUrl} alt={displayName} className="profile-photo" />
          ) : (
            <div className="profile-photo profile-photo-fallback">{initials || 'U'}</div>
          )}
        </div>

        {/* Name + badge */}
        <div className="profile-name-row">
          <h1 className="profile-name">{displayName}</h1>
          <span className="profile-badge">Open to work</span>
        </div>

        {/* Headline */}
        <p className="profile-headline">
          {profile.headline || 'Add a headline to describe your expertise'}
        </p>

        {/* Meta row */}
        <div className="profile-meta">
          {profile.location && (
            <>
              <MapPin size={13} strokeWidth={2} />
              <span>{profile.location}</span>
              <span className="profile-meta-sep" />
            </>
          )}

          {profileComplete ? (
            <>
              <CheckCircle2 size={13} strokeWidth={2} style={{ color: '#057642' }} />
              <span style={{ color: '#057642', fontWeight: 600 }}>Profile complete</span>
            </>
          ) : (
            <>
              <Clock size={13} strokeWidth={2} />
              <span>Profile incomplete — add more details</span>
            </>
          )}
        </div>

        {/* Summary */}
        {profile.summary && (
          <p className="profile-summary">{profile.summary}</p>
        )}

        {/* CTA actions */}
        <div className="profile-actions">
          {/* Visible seulement si onEdit existe */}
          {onEdit && (
            <button className="btn btn-primary" onClick={onEdit} type="button">
              <PencilLine size={15} strokeWidth={2} />
              Edit profile
            </button>
          )}

          <button className="btn btn-ghost" type="button" disabled>
            <MessageSquare size={15} strokeWidth={2} />
            Message
          </button>

          <button
            className="btn btn-ghost"
            type="button"
            disabled
            style={{ width: 40, padding: 0 }}
            aria-label="More options"
          >
            <MoreHorizontal size={15} strokeWidth={2} />
          </button>
        </div>
      </div>
    </section>
  );
};

export default ProfileHeader;