import React from 'react';
import { useNotification } from '../../hooks/useNotification';
import Navbar from '../Common/Navbar';

const NotificationsPage = () => {
  const { notifications, loading, error, deleteNotification } = useNotification();

  if (loading) {
    return (
      <div className="page-loader">
        <Navbar />
        <p>Chargement des notifications...</p>
      </div>
    );
  }

  return (
    <div className="notifications-page">
      <Navbar />
      <h2>Notifications</h2>

      {error && <div className="error-message">{error}</div>}

      {notifications.length === 0 && <p>Aucune notification.</p>}

      {notifications.map((notif) => (
        <div key={notif.id} className="notification card" style={{ marginBottom: '10px', padding: '10px' }}>
          <p>{notif.message}</p>
          <small>{new Date(notif.dateCreation).toLocaleString()}</small>
          <button onClick={() => deleteNotification(notif.id)}>🗑️ Supprimer</button>
        </div>
      ))}
    </div>
  );
};

export default NotificationsPage;