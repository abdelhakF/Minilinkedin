import React, { createContext, useCallback, useState } from 'react';
import postService from '../services/postService';

export const PostContext = createContext();

export const PostProvider = ({ children }) => {
  const [posts, setPosts] = useState([]);        // liste de posts (pour le feed perso)
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const normalizeError = (err) => {
    return err?.response?.data?.message || err?.response?.data || err.message || 'An error occurred';
  };

  // ───── CRÉATION ─────
  const createOffreStage = useCallback(async (offre) => {
    try {
      const newPost = await postService.createOffreStage(offre);
      setPosts((prev) => [newPost, ...prev]);
      return newPost;
    } catch (err) {
      setError(normalizeError(err));
      throw err;
    }
  }, []);

  const createSujetThese = useCallback(async (sujet) => {
    try {
      const newPost = await postService.createSujetThese(sujet);
      setPosts((prev) => [newPost, ...prev]);
      return newPost;
    } catch (err) {
      setError(normalizeError(err));
      throw err;
    }
  }, []);

  const createProjetTutore = useCallback(async (projet) => {
    try {
      const newPost = await postService.createProjetTutore(projet);
      setPosts((prev) => [newPost, ...prev]);
      return newPost;
    } catch (err) {
      setError(normalizeError(err));
      throw err;
    }
  }, []);

  const createDemande = useCallback(async (demande) => {
    try {
      const newPost = await postService.createDemande(demande);
      setPosts((prev) => [newPost, ...prev]);
      return newPost;
    } catch (err) {
      setError(normalizeError(err));
      throw err;
    }
  }, []);

  const createPublication = useCallback(async (publication) => {
    try {
      const newPost = await postService.createPublication(publication);
      setPosts((prev) => [newPost, ...prev]);
      return newPost;
    } catch (err) {
      setError(normalizeError(err));
      throw err;
    }
  }, []);

  // ───── INTERACTIONS ─────
  const likePost = useCallback(async (postId) => {
    try {
      await postService.likePost(postId);
      // Mise à jour locale du compteur (à adapter selon la structure réelle de Post)
      setPosts((prev) =>
        prev.map((p) => (p.id === postId ? { ...p, likesCount: (p.likesCount || 0) + 1 } : p))
      );
    } catch (err) {
      setError(normalizeError(err));
      throw err;
    }
  }, []);

  const unlikePost = useCallback(async (postId) => {
    try {
      await postService.unlikePost(postId);
      setPosts((prev) =>
        prev.map((p) => (p.id === postId ? { ...p, likesCount: Math.max((p.likesCount || 0) - 1, 0) } : p))
      );
    } catch (err) {
      setError(normalizeError(err));
      throw err;
    }
  }, []);

  const addComment = useCallback(async (postId, text) => {
    try {
      const comment = await postService.addComment(postId, text);
      // Ajouter le commentaire au post correspondant
      setPosts((prev) =>
        prev.map((p) =>
          p.id === postId
            ? { ...p, comments: [...(p.comments || []), comment] }
            : p
        )
      );
      return comment;
    } catch (err) {
      setError(normalizeError(err));
      throw err;
    }
  }, []);

  const sharePost = useCallback(async (postId, commentShare) => {
    try {
      await postService.sharePost(postId, commentShare);
      // logique de partage
    } catch (err) {
      setError(normalizeError(err));
      throw err;
    }
  }, []);

  // ───── CHARGEMENT ─────
  const fetchAllPosts = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await postService.getAllPosts();
      setPosts(data);
      return data;
    } catch (err) {
      setError(normalizeError(err));
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchMyPosts = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await postService.getMyPosts();
      setPosts(data);
      return data;
    } catch (err) {
      setError(normalizeError(err));
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  // ───── SUPPRESSION ─────
  const deleteMyPost = useCallback(async (id) => {
    try {
      await postService.deleteMyPost(id);
      setPosts((prev) => prev.filter((p) => p.id !== id));
    } catch (err) {
      setError(normalizeError(err));
      throw err;
    }
  }, []);

  // ───── SIGNALEMENT ─────
  const reportPost = useCallback(async (postId, motif) => {
    try {
      return await postService.reportPost(postId, motif);
    } catch (err) {
      setError(normalizeError(err));
      throw err;
    }
  }, []);

  const value = {
    posts,
    loading,
    error,
    createOffreStage,
    createSujetThese,
    createProjetTutore,
    createDemande,
    createPublication,
    likePost,
    unlikePost,
    addComment,
    sharePost,
    fetchAllPosts,
    fetchMyPosts,
    deleteMyPost,
    reportPost,
    setError,
  };

  return (
    <PostContext.Provider value={value}>
      {children}
    </PostContext.Provider>
  );
};