import axios from 'axios';

const API_URL = 'http://localhost:8080/api/posts';

const getAuthHeader = () => {
  const token = localStorage.getItem('token');
  return token ? { Authorization: `Bearer ${token}` } : {};
};

const postService = {
  // ===================== CRÉATION =====================

  createOffreStage: async (offre) => {
    const res = await axios.post(`${API_URL}/offre-stage`, offre, {
      headers: getAuthHeader(),
    });
    return res.data; // OffreStage
  },

  createSujetThese: async (sujet) => {
    const res = await axios.post(`${API_URL}/sujet-these`, sujet, {
      headers: getAuthHeader(),
    });
    return res.data; // SujetThese
  },

  createProjetTutore: async (projet) => {
    const res = await axios.post(`${API_URL}/projet-tutore`, projet, {
      headers: getAuthHeader(),
    });
    return res.data; // ProjetTuteure
  },

  createDemande: async (demande) => {
    const res = await axios.post(`${API_URL}/demande`, demande, {
      headers: getAuthHeader(),
    });
    return res.data; // DemandePost
  },

  createPublication: async (publication) => {
    const res = await axios.post(`${API_URL}/publication`, publication, {
      headers: getAuthHeader(),
    });
    return res.data; // PublicationPost
  },

  // ===================== INTERACTIONS =====================

  likePost: async (postId) => {
    const res = await axios.post(`${API_URL}/${postId}/like`, {}, {
      headers: getAuthHeader(),
    });
    return res.data; // string message
  },

  unlikePost: async (postId) => {
    const res = await axios.delete(`${API_URL}/${postId}/like`, {
      headers: getAuthHeader(),
    });
    return res.data; // string message
  },

  addComment: async (postId, text) => {
    // Le backend attend un String brut dans le body (Content-Type: text/plain)
    const res = await axios.post(`${API_URL}/${postId}/comment`, text, {
      headers: {
        ...getAuthHeader(),
        'Content-Type': 'text/plain',
      },
    });
    return res.data; // Comment
  },

  sharePost: async (postId, commentShare) => {
    // commentShare peut être null, on envoie un objet JSON ou du texte
    const res = await axios.post(
      `${API_URL}/${postId}/share`,
      commentShare || '',
      {
        headers: {
          ...getAuthHeader(),
          'Content-Type': 'text/plain',
        },
      }
    );
    return res.data; // string message
  },

  // ===================== RÉCUPÉRATION =====================

  getAllPosts: async () => {
    const res = await axios.get(API_URL, {
      headers: getAuthHeader(),
    });
    return res.data; // List<Post>
  },

  getMyPosts: async () => {
    const res = await axios.get(`${API_URL}/me`, {
      headers: getAuthHeader(),
    });
    return res.data; // List<Post>
  },

  getPostById: async (id) => {
    const res = await axios.get(`${API_URL}/${id}`, {
      headers: getAuthHeader(),
    });
    return res.data; // Post
  },

  // ===================== SUPPRESSION =====================

  deleteMyPost: async (id) => {
    const res = await axios.delete(`${API_URL}/${id}/me`, {
      headers: getAuthHeader(),
    });
    return res.data; // rien (void)
  },

  // ===================== SIGNALEMENT =====================

  reportPost: async (postId, motif) => {
    const res = await axios.post(
      'http://localhost:8080/api/signalements',
      { postId, motif },
      { headers: getAuthHeader() }
    );
    return res.data; // Signalement
  },
};

export default postService;