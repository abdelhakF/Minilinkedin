import axios from 'axios';

const API_URL = 'http://localhost:8080/api/candidatures';

const getAuthHeader = () => {
  const token = localStorage.getItem('token');
  return token ? { Authorization: `Bearer ${token}` } : {};
};

const candidatureService = {
  // Postuler à une offre (envoie le corps de la candidature + postId en param)
  postuler: async (candidature, postId) => {
    const res = await axios.post(`${API_URL}?postId=${postId}`, candidature, {
      headers: getAuthHeader(),
    });
    return res.data; // Candidature
  },

  // Récupérer les candidatures pour un post (enseignant/admin)
  getByPost: async (postId) => {
    const res = await axios.get(`${API_URL}/post/${postId}`, {
      headers: getAuthHeader(),
    });
    return res.data; // List<Candidature>
  },

  // Récupérer mes propres candidatures (étudiant)
  getMyCandidatures: async () => {
    const res = await axios.get(`${API_URL}/me`, {
      headers: getAuthHeader(),
    });
    return res.data; // List<CandidatureResponseDTO>
  },
};

export default candidatureService;