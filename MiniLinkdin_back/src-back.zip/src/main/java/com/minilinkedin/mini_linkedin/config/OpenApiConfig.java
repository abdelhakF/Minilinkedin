package com.minilinkedin.mini_linkedin.config;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration for OpenAPI (Swagger) documentation.
 * This setup defines the general API information and configures JWT-based security.
 */
@Configuration
@OpenAPIDefinition(
    info = @Info(
        title = "Mini-LinkedIn API",
        version = "v1",
        description = "This document describes the API for the Mini-LinkedIn backend application."
    ),
    // Apply security globally to all endpoints
    security = @SecurityRequirement(name = "bearerAuth") ,
    tags = {
            @Tag(name = "Module 1 — Authentication" , description = "Gestion des action de connexion"),
            @Tag(name = "Module 2 — Administration" , description="Espace de l'administrateur"),
            @Tag(name = "Module 3 — Réseau Social" , description = "Gestion du réseau social"),
            @Tag(name = "Module 4 — Recherche" , description = "Gestion de la recherche"),
            @Tag(name = "Module 5 — Profile", description = "Gestion des profiles"),
            @Tag(name = "Module 6 — Posts", description = "Gestion des posts"),
            @Tag(name = "Module 7 — Upload", description = "Gestion des Uploads"),
            @Tag(name = "Module 8 — Notifications", description = "Gestion des notifications"),
            @Tag(name = "Module 9 — Candidatures" , description = "Gestion des candidatures")
        }
)
@SecurityScheme(
    name = "bearerAuth",
    type = SecuritySchemeType.HTTP,
    scheme = "bearer",
    bearerFormat = "JWT",
    description = "JWT Authorization header using the Bearer scheme. " +
                  "Enter 'Bearer' [space] and then your token in the text input below. " +
                  "Example: Bearer 12345abcdef"
)
public class OpenApiConfig {
}
