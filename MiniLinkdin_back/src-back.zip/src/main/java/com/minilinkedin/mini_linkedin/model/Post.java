// mini-linkedin/src/main/java/com/minilinkedin/mini_linkedin/model/Post.java

package com.minilinkedin.mini_linkedin.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Data
@NoArgsConstructor
@AllArgsConstructor
public abstract class Post {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String titre;
    private String description;

    // 📸 IMAGE DU POST
    private String imageUrl;

    private LocalDate datePublication;
    private LocalDate dateLimite;

    @ManyToOne
    @JoinColumn(name = "auteur_id")
    private Utilisateur auteur;

    @OneToMany(mappedBy = "post", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnoreProperties("post")
    private List<Candidature> candidatures = new ArrayList<>();

    private int likeCount = 0;
    private int shareCount = 0;

    @PrePersist
    protected void onCreate() {
        this.datePublication = LocalDate.now();
    }
}