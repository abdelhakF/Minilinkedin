package com.minilinkedin.mini_linkedin.repository; // (ou Repositories selon ton dossier)

import com.minilinkedin.mini_linkedin.model.Notification; // <-- CHANGEMENT ICI
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> { // <-- CHANGEMENT ICI
    
   List<Notification> findByRecipient_Email(String email);

   void deleteByRecipient_Id(Long recipientId);
}