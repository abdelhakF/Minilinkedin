package com.minilinkedin.mini_linkedin.service;

import com.minilinkedin.mini_linkedin.dto.CandidatureResponseDTO;
import com.minilinkedin.mini_linkedin.model.Candidature;
import com.minilinkedin.mini_linkedin.model.Etudiant;
import com.minilinkedin.mini_linkedin.model.Post;
import com.minilinkedin.mini_linkedin.repository.CandidatureRepository;
import com.minilinkedin.mini_linkedin.repository.PostRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class CandidatureService {

    private final CandidatureRepository candidatureRepository;
    private final PostRepository postRepository;

    public CandidatureService(CandidatureRepository candidatureRepository, PostRepository postRepository) {
        this.candidatureRepository = candidatureRepository;
        this.postRepository = postRepository;
    }

    public Candidature postuler(Candidature candidature, Long postId, Etudiant etudiant) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new RuntimeException("Post non trouvé avec l'ID : " + postId));

        candidature.setPost(post);
        candidature.setEtudiant(etudiant);
        candidature.setDateDepot(LocalDate.now());

        return candidatureRepository.save(candidature);
    }

    public List<Candidature> getCandidaturesByPost(Long postId) {
        return candidatureRepository.findByPostId(postId);
    }

    public List<Candidature> getCandidaturesByEtudiant(Long etudiantId) {
        return candidatureRepository.findByEtudiantId(etudiantId);
    }

    /**
     * Nouvelle méthode pour éviter la récursion infinie
     */
    public List<CandidatureResponseDTO> getMyCandidaturesDTO(Long etudiantId) {
        List<Candidature> candidatures = candidatureRepository.findByEtudiantId(etudiantId);

        return candidatures.stream().map(c -> {
            CandidatureResponseDTO dto = new CandidatureResponseDTO();
            dto.setId(c.getId());
            dto.setMessageMotivation(c.getMessageMotivation());
            dto.setDateDepot(c.getDateDepot());

            // Informations du Post
            if (c.getPost() != null) {
                dto.setPostId(c.getPost().getId());
                dto.setPostTitre(c.getPost().getTitre());
                dto.setPostDescription(c.getPost().getDescription());
            }

            // Informations de l'étudiant
            if (c.getEtudiant() != null) {
                dto.setEtudiantId(c.getEtudiant().getId());
                dto.setEtudiantNom(c.getEtudiant().getNom());
                dto.setEtudiantEmail(c.getEtudiant().getEmail());
            }

            return dto;
        }).toList();
    }


}