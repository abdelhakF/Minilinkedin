// src/main/java/com/minilinkedin/mini_linkedin/controller/PostController.java
package com.minilinkedin.mini_linkedin.controller;

import com.minilinkedin.mini_linkedin.model.*;
import com.minilinkedin.mini_linkedin.service.PostService;
import com.minilinkedin.mini_linkedin.service.UserService;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/posts")
@Tag(name = "Module 6 — Posts", description = "Gestion des posts")// À modifier en production

public class PostController {

    private final PostService postService;
    private final UserService userService;

    public PostController(PostService postService, UserService userService) {
        this.postService = postService;
        this.userService = userService;
    }

    // ====================== POSTS ENSEIGNANTS ======================
    @PostMapping("/offre-stage")
    public ResponseEntity<OffreStage> createOffreStage(@RequestBody OffreStage offre, Authentication auth) {
        Utilisateur auteur = userService.getCurrentUser(auth.getName());
        if (auteur.getRoleEnum() != TypeRole.ENSEIGNANT && auteur.getRoleEnum() != TypeRole.ADMIN) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        return ResponseEntity.ok((OffreStage) postService.createPost(offre, auteur));
    }

    @PostMapping("/sujet-these")
    public ResponseEntity<SujetThese> createSujetThese(@RequestBody SujetThese sujet, Authentication auth) {
        Utilisateur auteur = userService.getCurrentUser(auth.getName());
        if (auteur.getRoleEnum() != TypeRole.ENSEIGNANT && auteur.getRoleEnum() != TypeRole.ADMIN) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        return ResponseEntity.ok((SujetThese) postService.createPost(sujet, auteur));
    }

    // ====================== PROJET TUTORÉ (autorisé pour ETUDIANT + ENSEIGNANT + ADMIN) ======================
    @PostMapping("/projet-tutore")
    public ResponseEntity<ProjetTuteure> createProjetTutore(@RequestBody ProjetTuteure projet, Authentication auth) {
        Utilisateur auteur = userService.getCurrentUser(auth.getName());

        // ✅ NOUVEAU : autorisé pour les étudiants aussi
        if (auteur.getRoleEnum() != TypeRole.ETUDIANT &&
                auteur.getRoleEnum() != TypeRole.ENSEIGNANT &&
                auteur.getRoleEnum() != TypeRole.ADMIN) {

            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        return ResponseEntity.ok((ProjetTuteure) postService.createPost(projet, auteur));
    }

    // ====================== POSTS ÉTUDIANTS ======================
    @PostMapping("/demande")
    public ResponseEntity<DemandePost> createDemande(@RequestBody DemandePost demande, Authentication auth) {
        Utilisateur auteur = userService.getCurrentUser(auth.getName());
        if (auteur.getRoleEnum() != TypeRole.ETUDIANT) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        return ResponseEntity.ok((DemandePost) postService.createPost(demande, auteur));
    }

    // ====================== PUBLICATION NORMALE (Pour tous) ======================
    @PostMapping("/publication")
    public ResponseEntity<PublicationPost> createPublication(@RequestBody PublicationPost publication, Authentication auth) {
        Utilisateur auteur = userService.getCurrentUser(auth.getName());
        if (auteur.getRoleEnum() != TypeRole.ETUDIANT && auteur.getRoleEnum() != TypeRole.ENSEIGNANT) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        return ResponseEntity.ok((PublicationPost) postService.createPost(publication, auteur));
    }

    // ====================== INTERACTIONS ======================
    @PostMapping("/{postId}/like")
    public ResponseEntity<String> likePost(@PathVariable Long postId, Authentication auth) {
        Utilisateur user = userService.getCurrentUser(auth.getName());
        postService.likePost(postId, user);
        return ResponseEntity.ok("Post liké avec succès");
    }

    @DeleteMapping("/{postId}/like")
    public ResponseEntity<String> unlikePost(@PathVariable Long postId, Authentication auth) {
        Utilisateur user = userService.getCurrentUser(auth.getName());
        postService.unlikePost(postId, user);
        return ResponseEntity.ok("Like retiré");
    }

    @PostMapping("/{postId}/comment")
    public ResponseEntity<Comment> addComment(@PathVariable Long postId,
                                              @RequestBody String text,
                                              Authentication auth) {
        Utilisateur user = userService.getCurrentUser(auth.getName());
        Comment comment = postService.addComment(postId, user, text);
        return ResponseEntity.ok(comment);
    }

    @PostMapping("/{postId}/share")
    public ResponseEntity<String> sharePost(@PathVariable Long postId,
                                            @RequestBody(required = false) String commentShare,
                                            Authentication auth) {
        Utilisateur user = userService.getCurrentUser(auth.getName());
        postService.sharePost(postId, user, commentShare);
        return ResponseEntity.ok("Post partagé avec succès");
    }

    // Récupération
    @GetMapping
    public ResponseEntity<List<Post>> getAllPosts() {
        return ResponseEntity.ok(postService.getAllPosts());
    }

    @GetMapping("/me")
    public ResponseEntity<List<Post>> getMyPosts(Authentication auth) {
        return ResponseEntity.ok(postService.getPostsByAuteurEmail(auth.getName()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Post> getPostById(@PathVariable Long id) {
        return postService.getPostById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}/me")
    public ResponseEntity<Void> deleteMyPost(@PathVariable Long id, Authentication auth) {
        try {
            boolean deleted = postService.deleteMyPost(id, auth.getName());
            return deleted ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
    }
}