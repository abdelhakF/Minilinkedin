package com.minilinkedin.mini_linkedin.service;

import com.minilinkedin.mini_linkedin.model.*;
import com.minilinkedin.mini_linkedin.repository.NotificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    // ==========================================
    // 1. LES DEUX MÉTHODES MANQUANTES 
    // ==========================================

    /**
     * Récupère toutes les notifications d'un utilisateur grâce à son email
     */
    public List<Notification> getNotificationsForUser(String username) {
        // En Spring Security, le "username" est souvent l'email de l'utilisateur
        return notificationRepository.findByRecipient_Email(username);
    }

    /**
     * Supprime une notification en vérifiant que l'utilisateur en est bien le propriétaire
     */
    public void deleteNotification(Long notificationId, String username) {
        Optional<Notification> notificationOpt = notificationRepository.findById(notificationId);
        
        if (notificationOpt.isPresent()) {
            Notification notification = notificationOpt.get();
            
            // Sécurité : On vérifie que c'est bien la notification de la bonne personne
            if (notification.getRecipient().getEmail().equals(username)) {
                notificationRepository.deleteById(notificationId);
            } else {
                throw new SecurityException("Action non autorisée.");
            }
        } else {
            throw new RuntimeException("Notification introuvable.");
        }
    }

    // ==========================================
    // 2. LA MÉTHODE POUR CRÉER (Qu'on a faite tout à l'heure)
    // ==========================================
    
    public void envoyerNotification(Utilisateur destinataire, NotificationType type, Long relatedId, String message) {
        Notification notif = new Notification();
        notif.setRecipient(destinataire);
        notif.setType(type);
        notif.setRelatedId(relatedId);
        notif.setContent(message);
        
        notificationRepository.save(notif);
    }

    public void envoyerNotificationMessage(Utilisateur destinataire, Message linkedMessage, String message) {
        Notification notif = new Notification();
        notif.setRecipient(destinataire);
        notif.setType(NotificationType.MESSAGE);
        notif.setRelatedId(linkedMessage.getId());
        notif.setMessage(linkedMessage);
        notif.setContent(message);

        notificationRepository.save(notif);
    }

    public void deleteById(Long id) {
    notificationRepository.deleteById(id);
}
}