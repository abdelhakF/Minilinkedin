package com.minilinkedin.mini_linkedin.service;

import com.minilinkedin.mini_linkedin.dto.*;
import com.minilinkedin.mini_linkedin.model.*;
import com.minilinkedin.mini_linkedin.repository.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class SocialNetworkService {

    @Autowired private UtilisateurRepository utilisateurRepository;
    @Autowired private ConnectionInvitationRepository invitationRepository;
    @Autowired private MessageRepository messageRepository;
    @Autowired private CommentRepository commentRepository;
    @Autowired private PostRepository postRepository;
    @Autowired private NotificationService notificationService;

    @Transactional
    public ConnectionInvitation envoyerInvitation(String senderEmail, InvitationRequest request) {
        Utilisateur sender = utilisateurRepository.findByEmail(senderEmail).orElseThrow();
        Utilisateur receiver = utilisateurRepository.findById(request.getReceiverId()).orElseThrow();

        if (Objects.equals(sender.getId(), receiver.getId())) throw new IllegalArgumentException("Impossible");
        if (invitationRepository.findBySenderAndSentTo(sender, receiver.getId()).isPresent())
            throw new IllegalStateException("Invitation existe déjà");

        ConnectionInvitation newInvitation = new ConnectionInvitation();
        newInvitation.setSender(sender); 
        newInvitation.setSentTo(receiver.getId());
        newInvitation.setStatus(ConnectionInvitationStatus.PENDING);
        ConnectionInvitation savedInvitation = invitationRepository.save(newInvitation);

        notificationService.envoyerNotification(receiver, NotificationType.CONNECTION, savedInvitation.getId(), "Nouvelle invitation.");
        return savedInvitation;
    }

    @Transactional
    public ConnectionInvitation accepterInvitation(String receiverEmail, Long invitationId) {
        ConnectionInvitation inv = invitationRepository.findById(invitationId).orElseThrow();
        Utilisateur dest = utilisateurRepository.findById(inv.getSentTo()).orElseThrow();
        if (!dest.getEmail().equals(receiverEmail)) throw new SecurityException("Interdit");
        inv.setStatus(ConnectionInvitationStatus.ACCEPTED);
        return invitationRepository.save(inv);
    }

    @Transactional
    public ConnectionInvitation refuserInvitation(String receiverEmail, Long invitationId) {
        ConnectionInvitation inv = invitationRepository.findById(invitationId).orElseThrow();
        Utilisateur dest = utilisateurRepository.findById(inv.getSentTo()).orElseThrow();
        if (!dest.getEmail().equals(receiverEmail)) throw new SecurityException("Interdit");
        inv.setStatus(ConnectionInvitationStatus.REJECTED);
        return invitationRepository.save(inv);
    }

    @Transactional
    public void annulerInvitation(String senderEmail, Long invitationId) {
        ConnectionInvitation inv = invitationRepository.findById(invitationId).orElseThrow();
        if (!inv.getSender().getEmail().equals(senderEmail)) throw new SecurityException("Interdit");
        inv.setStatus(ConnectionInvitationStatus.CANCELED);
        invitationRepository.save(inv);
    }

    public List<ConnectionInvitation> getInvitationsRecues(String email) {
        Utilisateur user = utilisateurRepository.findByEmail(email).orElseThrow();
        return invitationRepository.findBySentToAndStatus(user.getId(), ConnectionInvitationStatus.PENDING);
    }

    public List<ConnectionInvitation> getInvitationsEnvoyees(String email) {
        Utilisateur user = utilisateurRepository.findByEmail(email).orElseThrow();
        return invitationRepository.findBySenderAndStatus(user, ConnectionInvitationStatus.PENDING);
    }

    public List<Utilisateur> getMesConnexions(String email) {
        Utilisateur user = utilisateurRepository.findByEmail(email).orElseThrow();
        return invitationRepository.findAllConnectionsOf(user, user.getId()).stream()
                .map(inv -> inv.getSender().getEmail().equals(email) ? utilisateurRepository.findById(inv.getSentTo()).orElse(null) : inv.getSender())
                .filter(Objects::nonNull).collect(Collectors.toList());
    }

    @Transactional
    public Message envoyerMessage(String senderEmail, MessageRequest request) {
        Utilisateur sender = utilisateurRepository.findByEmail(senderEmail).orElseThrow();
        Utilisateur receiver = utilisateurRepository.findById(request.getReceiverId()).orElseThrow();

        Message msg = new Message();
        msg.setSender(sender);
        msg.setSendTo(receiver.getId());
        msg.setMessageBody(request.getMessageBody());
        Message savedMessage = messageRepository.save(msg);

        notificationService.envoyerNotificationMessage(receiver, savedMessage, "Nouveau message");
        return savedMessage;
    }

    public List<Message> getConversation(String currentUserEmail, Long otherUserId) {
        Utilisateur me = utilisateurRepository.findByEmail(currentUserEmail).orElseThrow();
        Utilisateur other = utilisateurRepository.findById(otherUserId).orElseThrow();
        return messageRepository.findConversation(me, other, me.getId(), other.getId());
    }

    public List<Message> getBoiteReception(String email) {
        Utilisateur user = utilisateurRepository.findByEmail(email).orElseThrow();
        return messageRepository.findBySendToOrderBySentAtDesc(user.getId());
    }

    public List<Post> getFilActualite(String email) {
        return postRepository.findAllByOrderByDatePublicationDesc();
    }

    @Transactional
    public Comment commenter(String authorEmail, CommentRequest request) {
        Utilisateur author = utilisateurRepository.findByEmail(authorEmail).orElseThrow();
        Post post = postRepository.findById(request.getPostId()).orElseThrow();

        Comment comment = new Comment();
        comment.setUser(author);
        comment.setPost(post);
        comment.setText(request.getText()); // <-- Changez 'getContenu()' par le bon nom de votre DTO si besoin
        comment.setTotalLikes(0);
        return commentRepository.save(comment);
    }

    public List<Comment> getCommentaires(Long postId) {
        Post post = postRepository.findById(postId).orElseThrow();
        return commentRepository.findByPostOrderByCreatedAtDesc(post);
    }

    @Transactional
    public Comment likerCommentaire(Long commentId) {
        Comment comment = commentRepository.findById(commentId).orElseThrow();
        comment.setTotalLikes(comment.getTotalLikes() + 1);
        return commentRepository.save(comment);
    }

    @Transactional
    public void supprimerCommentaire(String authorEmail, Long commentId) {
        Comment comment = commentRepository.findById(commentId).orElseThrow();
        if (!comment.getUser().getEmail().equals(authorEmail)) throw new SecurityException("Interdit");
        commentRepository.delete(comment);
    }
}
