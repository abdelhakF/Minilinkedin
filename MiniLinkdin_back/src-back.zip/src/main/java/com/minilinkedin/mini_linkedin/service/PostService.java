package com.minilinkedin.mini_linkedin.service;

import com.minilinkedin.mini_linkedin.model.*;
import com.minilinkedin.mini_linkedin.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PostService {

    private final PostRepository postRepository;
    private final PostLikeRepository postLikeRepository;
    private final PostShareRepository postShareRepository;
    private final CommentRepository commentRepository;

    // === AJOUT POUR LES NOTIFICATIONS ===
    private final NotificationService notificationService;

    @Autowired
    public PostService(PostRepository postRepository,
                       PostLikeRepository postLikeRepository,
                       PostShareRepository postShareRepository,
                       CommentRepository commentRepository,
                       NotificationService notificationService) {
        this.postRepository = postRepository;
        this.postLikeRepository = postLikeRepository;
        this.postShareRepository = postShareRepository;
        this.commentRepository = commentRepository;
        this.notificationService = notificationService;
    }

    // ====================== CRÉATION POST ======================
    public Post createPost(Post post, Utilisateur auteur) {
        post.setAuteur(auteur);
        return postRepository.save(post);
    }

    // ====================== LIKE ======================
    public void likePost(Long postId, Utilisateur user) {

        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new RuntimeException("Post non trouvé"));

        if (postLikeRepository.existsByPostAndUser(post, user)) return;

        PostLike like = new PostLike();
        like.setPost(post);
        like.setUser(user);

        postLikeRepository.save(like);

        post.setLikeCount(post.getLikeCount() + 1);
        postRepository.save(post);

        notificationService.envoyerNotification(
                post.getAuteur(),
                NotificationType.LIKE,
                post.getId(),
                user.getNom() + " a aimé votre publication"
        );
    }

    public void unlikePost(Long postId, Utilisateur user) {

        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new RuntimeException("Post non trouvé"));

        Optional<PostLike> likeOpt =
                postLikeRepository.findByPostAndUser(post, user);

        if (likeOpt.isPresent()) {
            postLikeRepository.delete(likeOpt.get());

            post.setLikeCount(Math.max(0, post.getLikeCount() - 1));
            postRepository.save(post);
        }
    }

    // ====================== SHARE ======================
    public void sharePost(Long postId, Utilisateur user, String commentShare) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new RuntimeException("Post non trouvé"));

        post.setShareCount(post.getShareCount() + 1);
        postRepository.save(post);

        PostShare share = new PostShare();
        share.setPost(post);
        share.setUser(user);
        share.setCommentShare(commentShare);
        postShareRepository.save(share);

        // === NOTIFICATION SHARE ===
        String message = (commentShare != null && !commentShare.isEmpty())
                ? user.getNom() + " a partagé votre publication avec un commentaire"
                : user.getNom() + " a partagé votre publication";

        notificationService.envoyerNotification(
                post.getAuteur(),
                NotificationType.SHARE,
                post.getId(),
                message
        );
    }

    // ====================== COMMENT ======================
    public Comment addComment(Long postId, Utilisateur user, String text) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new RuntimeException("Post non trouvé"));

        Comment comment = new Comment();
        comment.setText(text);
        comment.setPost(post);
        comment.setUser(user);
        Comment savedComment = commentRepository.save(comment);

        // === NOTIFICATION COMMENT ===
        notificationService.envoyerNotification(
                post.getAuteur(),
                NotificationType.COMMENT,
                post.getId(),
                user.getNom() + " a commenté votre publication : " + text
        );

        return savedComment;
    }

    // ====================== AUTRES MÉTHODES (inchangées) ======================
    public List<Post> getAllPosts() {
        return postRepository.findAll();
    }

    public List<Post> getPostsByAuteurEmail(String email) {
        return postRepository.findByAuteurEmailOrderByDatePublicationDesc(email);
    }

    public boolean deleteMyPost(Long postId, String email) {
        Optional<Post> postOpt = postRepository.findById(postId);
        if (postOpt.isEmpty()) {
            return false;
        }

        Post post = postOpt.get();
        if (post.getAuteur() == null || post.getAuteur().getEmail() == null
                || !post.getAuteur().getEmail().equalsIgnoreCase(email)) {
            throw new SecurityException("Action non autorisée.");
        }

        postRepository.delete(post);
        return true;
    }

    public Optional<Post> getPostById(Long id) {
        return postRepository.findById(id);
    }
}