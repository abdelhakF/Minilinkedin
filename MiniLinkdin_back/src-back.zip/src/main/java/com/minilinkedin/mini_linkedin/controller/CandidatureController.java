package com.minilinkedin.mini_linkedin.controller;

import com.minilinkedin.mini_linkedin.dto.CandidatureResponseDTO;
import com.minilinkedin.mini_linkedin.model.Candidature;
import com.minilinkedin.mini_linkedin.model.Etudiant;
import com.minilinkedin.mini_linkedin.model.Utilisateur;
import com.minilinkedin.mini_linkedin.service.CandidatureService;
import com.minilinkedin.mini_linkedin.service.UserService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/candidatures")
@Tag(name = "Module 9 — Candidatures" , description = "Gestion des candidatures")
public class CandidatureController {

    private final CandidatureService candidatureService;
    private final UserService userService;

    public CandidatureController(CandidatureService candidatureService, UserService userService) {
        this.candidatureService = candidatureService;
        this.userService = userService;
    }

    @PostMapping
    public ResponseEntity<Candidature> postuler(
            @RequestBody Candidature candidature,
            @RequestParam Long postId,
            Authentication authentication) {

        Utilisateur user = userService.getCurrentUser(authentication.getName());

        if (!(user instanceof Etudiant etudiant)) {
            return ResponseEntity.badRequest().body(null);
        }

        Candidature saved = candidatureService.postuler(candidature, postId, etudiant);
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/post/{postId}")
    public ResponseEntity<List<Candidature>> getByPost(@PathVariable Long postId) {
        return ResponseEntity.ok(candidatureService.getCandidaturesByPost(postId));
    }

    @GetMapping("/me")
    public ResponseEntity<List<CandidatureResponseDTO>> getMyCandidatures(Authentication authentication) {
        Utilisateur user = userService.getCurrentUser(authentication.getName());

        if (!(user instanceof Etudiant etudiant)) {
            return ResponseEntity.badRequest().build();
        }

        List<CandidatureResponseDTO> mesCandidatures = candidatureService.getMyCandidaturesDTO(etudiant.getId());
        return ResponseEntity.ok(mesCandidatures);
    }
}