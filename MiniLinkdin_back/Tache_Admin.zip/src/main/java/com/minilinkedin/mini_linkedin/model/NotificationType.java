package com.minilinkedin.mini_linkedin.model;

public enum NotificationType {
    MESSAGE,
    CONNECTION,
    RECOMMENDATION,
    COMMENT,
    VISITE
}