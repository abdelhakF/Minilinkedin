package com.minilinkedin.mini_linkedin.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
public class Notification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long notificationId;

    private String content; // Le texte à afficher

    private LocalDate createdOn;

    private boolean isRead = false; // Très utile pour afficher les "nouvelles" notifications

    // --- LA SOLUTION SIMPLE EST ICI --- //

    @Enumerated(EnumType.STRING)
    private NotificationType type; // Savoir de quoi on parle (MESSAGE, COMMENT...)

    private Long relatedId; // L'ID de l'objet (l'ID du message, du commentaire, etc.)

    @ManyToOne
    @JoinColumn(name = "recipient_id", nullable = false)
    private Utilisateur recipient; // La personne qui reçoit la notification

    @PrePersist
    protected void onCreate() {
        this.createdOn = LocalDate.now();
    }
}