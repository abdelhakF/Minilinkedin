package com.minilinkedin.mini_linkedin.controller;

import com.minilinkedin.mini_linkedin.model.Notification;
import com.minilinkedin.mini_linkedin.service.NotificationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
@Tag(name = "Notifications", description = "Gestion des notifications")
@CrossOrigin(origins = "*")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    // CHANGEMENT : On passe l'email dans l'URL pour simuler l'utilisateur
    @Operation(summary = "Récupérer les notifications d'un utilisateur par son email")
    @GetMapping("/user/{email}")
    public ResponseEntity<List<Notification>> getMyNotifications(@PathVariable String email) {
        // Plus besoin de UserDetails, on utilise l'email passé en paramètre
        return ResponseEntity.ok(notificationService.getNotificationsForUser(email));
    }

    // CHANGEMENT : On ne vérifie plus le propriétaire par sécurité pour l'instant
    @Operation(summary = "Supprimer une notification")
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteNotification(@PathVariable Long id) {
        try {
            // Version simplifiée pour le test
            notificationService.deleteById(id); 
            return ResponseEntity.ok("Notification supprimée");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}