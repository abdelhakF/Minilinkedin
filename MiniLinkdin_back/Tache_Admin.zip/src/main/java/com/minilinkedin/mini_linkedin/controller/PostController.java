package com.minilinkedin.mini_linkedin.controller;

import com.minilinkedin.mini_linkedin.model.OffreStage;
import com.minilinkedin.mini_linkedin.model.Post;
import com.minilinkedin.mini_linkedin.model.ProjetTuteure;
import com.minilinkedin.mini_linkedin.model.SujetThese;
import com.minilinkedin.mini_linkedin.model.Utilisateur;
import com.minilinkedin.mini_linkedin.service.PostService;
import com.minilinkedin.mini_linkedin.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/posts")
public class PostController {

    private final PostService postService;
    private final UserService userService;

    public PostController(PostService postService, UserService userService) {
        this.postService = postService;
        this.userService = userService;
    }

    @PostMapping("/offre-stage")
    public ResponseEntity<OffreStage> createOffreStage(
            @RequestBody OffreStage offre,
            Authentication authentication) {

        Utilisateur auteur = userService.getCurrentUser(authentication.getName());
        OffreStage saved = (OffreStage) postService.createPost(offre, auteur);
        return ResponseEntity.ok(saved);
    }

    @PostMapping("/sujet-these")
    public ResponseEntity<SujetThese> createSujetThese(
            @RequestBody SujetThese sujet,
            Authentication authentication) {

        Utilisateur auteur = userService.getCurrentUser(authentication.getName());
        SujetThese saved = (SujetThese) postService.createPost(sujet, auteur);
        return ResponseEntity.ok(saved);
    }

    @PostMapping("/projet-tutore")
    public ResponseEntity<ProjetTuteure> createProjetTutore(
            @RequestBody ProjetTuteure projet,
            Authentication authentication) {

        Utilisateur auteur = userService.getCurrentUser(authentication.getName());
        ProjetTuteure saved = (ProjetTuteure) postService.createPost(projet, auteur);
        return ResponseEntity.ok(saved);
    }

    @GetMapping
    public ResponseEntity<List<Post>> getAllPosts() {
        return ResponseEntity.ok(postService.getAllPosts());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Post> getPostById(@PathVariable Long id) {
        return postService.getPostById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePost(@PathVariable Long id) {
        postService.deletePost(id);
        return ResponseEntity.noContent().build();
    }
}