package com.minilinkedin.mini_linkedin.service;

import com.minilinkedin.mini_linkedin.model.*;
import com.minilinkedin.mini_linkedin.repository.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SearchService {

    @Autowired private UtilisateurRepository utilisateurRepository;
    @Autowired private PostRepository postRepository;
    @Autowired private SkillRepository skillRepository;

    // ══════════════════════════════════════════════
    // RECHERCHE D'UTILISATEURS
    // ══════════════════════════════════════════════

    public List<Utilisateur> rechercherParNom(String nom) {
        if (nom == null || nom.isBlank())
            throw new IllegalArgumentException("Le nom de recherche ne peut pas être vide");
        return utilisateurRepository.searchByNom(nom.trim());
    }

    public List<Utilisateur> rechercherParRole(TypeRole role) {
        return utilisateurRepository.findByRoleEnum(role);
    }

    public List<Utilisateur> rechercherParInstitution(String institution) {
        if (institution == null || institution.isBlank())
            throw new IllegalArgumentException("L'institution ne peut pas être vide");
        return utilisateurRepository.searchByInstitution(institution.trim());
    }

    // ══════════════════════════════════════════════
    // RECHERCHE D'ENSEIGNANTS
    // ══════════════════════════════════════════════

    public List<Enseignant> rechercherEnseignantParSpecialite(String specialite) {
        if (specialite == null || specialite.isBlank())
            throw new IllegalArgumentException("La spécialité ne peut pas être vide");
        return utilisateurRepository.searchEnseignantBySpecialite(specialite.trim());
    }

    // ══════════════════════════════════════════════
    // RECHERCHE DE POSTS
    // ══════════════════════════════════════════════

    public List<Post> rechercherPosts(String keyword) {
        if (keyword == null || keyword.isBlank())
            return postRepository.findAllByOrderByDatePublicationDesc();
        return postRepository.searchByKeyword(keyword.trim());
    }

    public List<OffreStage> getOffresStage() {
        return postRepository.getOffresStage();   // ← changé
    }

    public List<SujetThese> getSujetsThese() {
        return postRepository.getSujetsThese();   // ← changé
    }

    public List<ProjetTuteure> getProjetsTutores() {
        return postRepository.getProjetsTutores(); // ← changé
    }

    // Filtrage combiné : mot-clé + type (offre / these / projet)
    public List<Post> rechercherPostsParType(String keyword, String type) {
        if (type == null || type.isBlank())
            return rechercherPosts(keyword);

        String t = type.toLowerCase().trim();
        if (t.equals("offre")) {
            return rechercherPosts(keyword).stream()
                    .filter(p -> p instanceof OffreStage).collect(java.util.stream.Collectors.toList());
        } else if (t.equals("these")) {
            return rechercherPosts(keyword).stream()
                    .filter(p -> p instanceof SujetThese).collect(java.util.stream.Collectors.toList());
        } else if (t.equals("projet")) {
            return rechercherPosts(keyword).stream()
                    .filter(p -> p instanceof ProjetTuteure).collect(java.util.stream.Collectors.toList());
        } else {
            return rechercherPosts(keyword);
        }
    }

    // ══════════════════════════════════════════════
    // RECHERCHE DE COMPÉTENCES
    // ══════════════════════════════════════════════

    public List<Skill> rechercherCompetences(String keyword) {
        if (keyword == null || keyword.isBlank())
            return (List<Skill>) skillRepository.findAll();
        return skillRepository.searchByName(keyword.trim());
    }

    // ══════════════════════════════════════════════
    // RECHERCHE GLOBALE
    // ══════════════════════════════════════════════

    public record SearchGlobalResult(
            List<Utilisateur> utilisateurs,
            List<Post>        posts,
            List<Skill>       competences
    ) {}

    public SearchGlobalResult rechercheGlobale(String keyword) {
        return new SearchGlobalResult(
                rechercherParNom(keyword),
                rechercherPosts(keyword),
                rechercherCompetences(keyword)
        );
    }
}
