package com.minilinkedin.mini_linkedin.repository;

import com.minilinkedin.mini_linkedin.model.*;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CommentRepository extends CrudRepository<Comment, Long> {
    
    // Commentaires d'un post triés du plus récent
    List<Comment> findByPostOrderByCreatedAtDesc(Post post);

    // Commentaires d'un utilisateur
    List<Comment> findByUser(Utilisateur user);
}

