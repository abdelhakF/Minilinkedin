package com.minilinkedin.mini_linkedin.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;

@Entity
@Data
@NoArgsConstructor
public class Comment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Lob 
    private String text;

    private int totalLikes = 0;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(nullable = false, updatable = false)
    private Date createdAt;

    // --- RELATIONS ---

    /**
     * Le post sur lequel ce commentaire est publié
     */
    @ManyToOne
    @JoinColumn(name = "post_id", nullable = false)
    private Post post; // <--- C'ÉTAIT CETTE LIGNE QUI MANQUAIT

    /**
     * Chaque commentaire est lié à l'utilisateur qui l'a écrit
     */
    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private Utilisateur user;

    /**
     * Chaque commentaire est lié à une notification
     */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "notification_id")
    private Notification notification;

    @PrePersist
    protected void onCreate() {
        createdAt = new Date();
    }
}