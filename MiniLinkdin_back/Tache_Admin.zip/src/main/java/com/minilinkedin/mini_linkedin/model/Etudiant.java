package com.minilinkedin.mini_linkedin.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.util.List;

@Entity
@Data
@EqualsAndHashCode(callSuper = true)
@PrimaryKeyJoinColumn(name = "id")
public class Etudiant extends Utilisateur {
    private String niveauEtude;

    @OneToMany
    private List<Education> diplomes;

    @OneToMany
    private List<Experience> experiences;
}