package com.minilinkedin.mini_linkedin.dto;

public record DashboardStatsDTO(
    long totalUsers,
    long totalPosts,
    long totalTeachers
) {}
