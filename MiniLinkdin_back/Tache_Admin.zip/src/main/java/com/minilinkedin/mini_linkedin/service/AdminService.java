package com.minilinkedin.mini_linkedin.service;

import com.minilinkedin.mini_linkedin.dto.DashboardStatsDTO;
import com.minilinkedin.mini_linkedin.model.AccountStatus;
import com.minilinkedin.mini_linkedin.model.Enseignant;
import com.minilinkedin.mini_linkedin.model.Post;
import com.minilinkedin.mini_linkedin.model.Utilisateur;
import com.minilinkedin.mini_linkedin.repository.EnseignantRepository;
import com.minilinkedin.mini_linkedin.repository.PostRepository;
import com.minilinkedin.mini_linkedin.repository.UtilisateurRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.StreamSupport;

@Service
@RequiredArgsConstructor
@Transactional
public class AdminService {

    private final UtilisateurRepository utilisateurRepository;
    private final EnseignantRepository enseignantRepository;
    private final PostRepository postRepository;

    // --- Statistiques ---
    public DashboardStatsDTO getDashboardStats() {
        long totalUsers = utilisateurRepository.count();
        long totalPosts = postRepository.count();
        long totalTeachers = enseignantRepository.count();
        return new DashboardStatsDTO(totalUsers, totalPosts, totalTeachers);
    }

    // --- Gestion des Utilisateurs ---
    public List<Utilisateur> getAllUsers() {
        return StreamSupport.stream(utilisateurRepository.findAll().spliterator(), false).toList();
    }

    public Utilisateur getUserById(Long userId) {
        return utilisateurRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé avec l'ID : " + userId));
    }

    public Enseignant validateEnseignant(Long enseignantId) {
        Enseignant enseignant = enseignantRepository.findById(enseignantId)
                .orElseThrow(() -> new RuntimeException("Enseignant non trouvé avec l'ID : " + enseignantId));
        enseignant.setEstValide(true);
        return enseignantRepository.save(enseignant);
    }

    public Utilisateur banUser(Long userId) {
        return updateUserStatus(userId, AccountStatus.BANNED);
    }

    public Utilisateur unbanUser(Long userId) {
        return updateUserStatus(userId, AccountStatus.ACTIVE);
    }

    public void deleteUser(Long userId) {
        if (!utilisateurRepository.existsById(userId)) {
            throw new RuntimeException("Utilisateur non trouvé avec l'ID : " + userId);
        }
        utilisateurRepository.deleteById(userId);
    }

    // --- Gestion de Contenu ---
    public List<Post> getAllPosts() {
        return postRepository.findAll();
    }

    public void deletePost(Long postId) {
        if (!postRepository.existsById(postId)) {
            throw new RuntimeException("Post non trouvé avec l'ID : " + postId);
        }
        postRepository.deleteById(postId);
    }

    // --- Méthode privée utilitaire ---
    private Utilisateur updateUserStatus(Long userId, AccountStatus status) {
        Utilisateur user = utilisateurRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé avec l'ID : " + userId));
        if (user.getAccount() != null) {
            user.getAccount().setStatus(status);
            return utilisateurRepository.save(user);
        }
        throw new IllegalStateException("L'utilisateur n'a pas de compte associé.");
    }
}
