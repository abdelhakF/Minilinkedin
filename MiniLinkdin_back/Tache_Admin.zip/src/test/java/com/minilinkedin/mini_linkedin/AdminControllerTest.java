package com.minilinkedin.mini_linkedin;

import com.minilinkedin.mini_linkedin.controller.AdminController;
import com.minilinkedin.mini_linkedin.dto.DashboardStatsDTO;
import com.minilinkedin.mini_linkedin.model.AccountStatus;
import com.minilinkedin.mini_linkedin.model.Account;
import com.minilinkedin.mini_linkedin.model.Enseignant;
import com.minilinkedin.mini_linkedin.model.Post;
import com.minilinkedin.mini_linkedin.model.OffreStage; // Extends Post
import com.minilinkedin.mini_linkedin.model.Utilisateur;
import com.minilinkedin.mini_linkedin.service.AdminService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AdminController.class)
@AutoConfigureMockMvc(addFilters = false) // Disable security filters for unit testing controllers
public class AdminControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AdminService adminService;

    private Utilisateur mockUtilisateur;
    private Enseignant mockEnseignant;
    private Post mockPost;
    private Account mockAccount;

    @BeforeEach
    void setUp() {
        mockAccount = new Account();
        mockAccount.setId(1L);
        mockAccount.setStatus(AccountStatus.ACTIVE);

        mockUtilisateur = new Utilisateur();
        mockUtilisateur.setId(1L);
        mockUtilisateur.setNom("John Doe");
        mockUtilisateur.setEmail("test@admin.com");
        mockUtilisateur.setAccount(mockAccount);

        mockEnseignant = new Enseignant();
        mockEnseignant.setId(2L);
        mockEnseignant.setEstValide(true);

        // Post is abstract, so we use a concrete subclass or just a mocked instance. We use OffreStage here.
        OffreStage offre = new OffreStage();
        offre.setId(1L);
        offre.setTitre("Test post");
        offre.setDatePublication(LocalDate.now());
        mockPost = offre;
    }

    @Test
    void testGetDashboardStats() throws Exception {
        DashboardStatsDTO stats = new DashboardStatsDTO(10L, 5L, 2L);
        when(adminService.getDashboardStats()).thenReturn(stats);

        mockMvc.perform(get("/api/admin/stats"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalUsers").value(10))
                .andExpect(jsonPath("$.totalPosts").value(5))
                .andExpect(jsonPath("$.totalTeachers").value(2));

        verify(adminService, times(1)).getDashboardStats();
    }

    @Test
    void testGetAllUsers() throws Exception {
        List<Utilisateur> users = Arrays.asList(mockUtilisateur);
        when(adminService.getAllUsers()).thenReturn(users);

        mockMvc.perform(get("/api/admin/users"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1L))
                .andExpect(jsonPath("$[0].nom").value("John Doe"));

        verify(adminService, times(1)).getAllUsers();
    }

    @Test
    void testGetUserById() throws Exception {
        when(adminService.getUserById(1L)).thenReturn(mockUtilisateur);

        mockMvc.perform(get("/api/admin/users/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.nom").value("John Doe"));

        verify(adminService, times(1)).getUserById(1L);
    }

    @Test
    void testValidateEnseignant() throws Exception {
        when(adminService.validateEnseignant(2L)).thenReturn(mockEnseignant);

        mockMvc.perform(put("/api/admin/enseignants/2/validate"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(2L))
                .andExpect(jsonPath("$.estValide").value(true));

        verify(adminService, times(1)).validateEnseignant(2L);
    }

    @Test
    void testBanUser() throws Exception {
        mockAccount.setStatus(AccountStatus.BANNED);
        when(adminService.banUser(1L)).thenReturn(mockUtilisateur);

        mockMvc.perform(put("/api/admin/users/1/ban"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.account.status").value("BANNED"));

        verify(adminService, times(1)).banUser(1L);
    }

    @Test
    void testUnbanUser() throws Exception {
        when(adminService.unbanUser(1L)).thenReturn(mockUtilisateur);

        mockMvc.perform(put("/api/admin/users/1/unban"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.account.status").value("ACTIVE"));

        verify(adminService, times(1)).unbanUser(1L);
    }

    @Test
    void testDeleteUser() throws Exception {
        doNothing().when(adminService).deleteUser(1L);

        mockMvc.perform(delete("/api/admin/users/1"))
                .andExpect(status().isNoContent());

        verify(adminService, times(1)).deleteUser(1L);
    }

    @Test
    void testGetAllPosts() throws Exception {
        List<Post> posts = Arrays.asList(mockPost);
        when(adminService.getAllPosts()).thenReturn(posts);

        mockMvc.perform(get("/api/admin/posts"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1L))
                .andExpect(jsonPath("$[0].titre").value("Test post"));

        verify(adminService, times(1)).getAllPosts();
    }

    @Test
    void testDeletePost() throws Exception {
        doNothing().when(adminService).deletePost(1L);

        mockMvc.perform(delete("/api/admin/posts/1"))
                .andExpect(status().isNoContent());

        verify(adminService, times(1)).deletePost(1L);
    }
}
